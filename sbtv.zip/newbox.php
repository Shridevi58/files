<?php
if(isset($_POST['button_pressed']))
{
	
$webmaster_email = "shridevi.devops@gmail.com";
$thankyou= "thankyou.html";

$Full_Name = $_POST['Full_Name'] ;
$Mobile = $_POST['Mobile'] ;
$msg = 
"Full Name: " . $Full_Name . "\r\n" . 
"Mobile: " . $Mobile ;

mail( "$webmaster_email", "New Box Request", $msg );
header( "Location: $thankyou" );	
}
?>