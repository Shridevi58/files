<?php
if(isset($_POST['button_pressed']))
{
	
$webmaster_email = "shridevi.devops@gmail.com";
$feedback= "feedback.html";

$Full_Name = $_POST['Full_Name'] ;
$Mobile_Number= $_POST['Mobile_Number'] ;
$Complaint = $_POST['Complaint'] ;

$msg = 
"Full Name: " . $Full_Name . "\r\n" . 
"Mobile: " . $Mobile. "\r\n" .
"Complaint: " . $Complaint ;

mail( "$webmaster_email", "Customer Complaint", $msg );
header( "Location: $feedback" );
}
?>

